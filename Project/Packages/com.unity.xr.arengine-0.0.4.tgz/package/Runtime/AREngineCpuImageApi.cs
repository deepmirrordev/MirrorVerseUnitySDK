using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine.XR.ARSubsystems;

namespace UnityEngine.XR.AREngine
{

    public class AREngineCpuImageApi : XRCpuImage.Api
    {
        private static AREngineCpuImageApi s_Instance;
        public static AREngineCpuImageApi Instance
        {
            get
            {
                if (s_Instance == null)
                {
                    s_Instance = new AREngineCpuImageApi();
                }
                return s_Instance;
            }
        }

        private Dictionary<int, Task> taskDic;
        private Dictionary<int, GCHandle> dataDic;
        public AREngineCpuImageApi()
        {
            taskDic = new Dictionary<int, Task>();
            dataDic = new Dictionary<int, GCHandle>();
        }

        // Input-image registry. XRCpuImage.Cinfo.nativeHandle is an int, which
        // cannot hold a pointer-sized value: on IL2CPP (Unity 6000) both a raw
        // native pointer and a GCHandle.ToIntPtr() exceed 32 bits, so casting to
        // int truncates and the reconstructed handle dereferences garbage
        // (SIGSEGV) the moment Convert reads it. Instead we hand AR Foundation a
        // small monotonic int id and keep the acquired NV12 snapshot in this map.
        // The buffer is pinned so TryGetPlane can hand out stable pointers into
        // it for the lifetime of the image (until DisposeImage).
        private class InputImage
        {
            public GCHandle pinnedBytes;
            public int width;
            public int height;
            public byte[] Bytes => (byte[])pinnedBytes.Target;
        }

        private static int s_nextImageId = 1;
        private static readonly Dictionary<int, InputImage> s_inputImages = new Dictionary<int, InputImage>();
        private static readonly object s_inputImagesLock = new object();

        public static int RegisterInputImage(byte[] bytes, int width, int height)
        {
            lock (s_inputImagesLock)
            {
                int id = s_nextImageId++;
                if (s_nextImageId == int.MaxValue) s_nextImageId = 1;
                s_inputImages[id] = new InputImage
                {
                    pinnedBytes = GCHandle.Alloc(bytes, GCHandleType.Pinned),
                    width = width,
                    height = height,
                };
                return id;
            }
        }

        private static InputImage GetInputImage(int id)
        {
            lock (s_inputImagesLock)
            {
                return s_inputImages.TryGetValue(id, out InputImage image) ? image : null;
            }
        }

        private static void ReleaseInputImage(int id)
        {
            lock (s_inputImagesLock)
            {
                if (s_inputImages.TryGetValue(id, out InputImage image))
                {
                    image.pinnedBytes.Free();
                    s_inputImages.Remove(id);
                }
            }
        }


        public override int ConvertAsync(int nativeHandle, XRCpuImage.ConversionParams conversionParams)
        {
            byte[] bytes = GetInputImage(nativeHandle)?.Bytes;
            TextureFormat textureFormat = conversionParams.outputFormat;


            Task task = Task.Factory.StartNew(() =>
            {
                int width = conversionParams.inputRect.width;
                int height = conversionParams.inputRect.height;
                int targetWidth = conversionParams.outputDimensions.x;
                int targetHeight = conversionParams.outputDimensions.y;
                bool mirrorX = conversionParams.transformation.HasFlag(XRCpuImage.Transformation.MirrorX);
                bool mirrorY = conversionParams.transformation.HasFlag(XRCpuImage.Transformation.MirrorY);
                bytes = TextureUtils.DecodeYUV2RGB(bytes, TextureUtils.YuvType.NV12, width, height);
                bytes = TextureUtils.ResizeTexture(bytes, width, height,
                TextureUtils.ImageFilterMode.Biliner, targetWidth, targetHeight, mirrorX, mirrorY);
                switch (textureFormat)
                {
                    case TextureFormat.RGB24:

                        break;
                    case TextureFormat.RGBA32:
                        bytes = TextureUtils.RGB2RGBA32(bytes);
                        break;
                    case TextureFormat.ARGB32:
                        bytes = TextureUtils.RGB2ARGB32(bytes);
                        break;
                    case TextureFormat.BGRA32:
                        bytes = TextureUtils.RGB2BGRA32(bytes);
                        break;
                    default:
                        throw new NotImplementedException();

                }
                GCHandle handle = GCHandle.Alloc(bytes, GCHandleType.Pinned);
                if (dataDic.ContainsKey(nativeHandle))
                {
                    dataDic[nativeHandle] = handle;
                }
                else
                {
                    dataDic.Add(nativeHandle, handle);

                }

            });
            if (taskDic.ContainsKey(nativeHandle))
            {
                taskDic[nativeHandle] = task;

            }
            else
            {
                taskDic.Add(nativeHandle, task);
            }

            return nativeHandle;
        }
        public override void DisposeAsyncRequest(int requestId)
        {
            // requestId is our registry id (ConvertAsync returns the incoming
            // nativeHandle), not a GCHandle -- don't GCHandle.Free it. The output
            // buffer is the pinned handle tracked in dataDic below.
            if (taskDic.ContainsKey(requestId))
            {
                taskDic[requestId].Dispose();
                taskDic.Remove(requestId);
            }
            if (dataDic.ContainsKey(requestId))
            {
                dataDic[requestId].Free();
                dataDic.Remove(requestId);
            }

        }

        static readonly HashSet<TextureFormat> s_SupportedVideoConversionFormats = new HashSet<TextureFormat>
        {
            // TextureFormat.Alpha8,
            // TextureFormat.R8,
            // TextureFormat.R16,
            // TextureFormat.RFloat,
            TextureFormat.RGB24,
            TextureFormat.RGBA32,
            TextureFormat.ARGB32,
            TextureFormat.BGRA32,
        };
        public override bool FormatSupported(XRCpuImage image, TextureFormat format) => (((image.format == XRCpuImage.Format.AndroidYuv420_888) || (image.format == XRCpuImage.Format.DepthUint16) || (image.format == XRCpuImage.Format.OneComponent8))
                && s_SupportedVideoConversionFormats.Contains(format));
        public override void ConvertAsync(int nativeHandle, XRCpuImage.ConversionParams conversionParams, OnImageRequestCompleteDelegate callback, IntPtr context)
        {
            byte[] bytes = GetInputImage(nativeHandle)?.Bytes;
            TextureFormat textureFormat = conversionParams.outputFormat;
            SynchronizationContext synchronizationContext = SynchronizationContext.Current;

            Task task = Task.Factory.StartNew(() =>
            {
                try
                {
                    int width = conversionParams.inputRect.width;
                    int height = conversionParams.inputRect.height;
                    int targetWidth = conversionParams.outputDimensions.x;
                    int targetHeight = conversionParams.outputDimensions.y;
                    bool mirrorX = conversionParams.transformation.HasFlag(XRCpuImage.Transformation.MirrorX);
                    bool mirrorY = conversionParams.transformation.HasFlag(XRCpuImage.Transformation.MirrorY);
                    bytes = TextureUtils.DecodeYUV2RGB(bytes, TextureUtils.YuvType.NV12, width, height);
                    bytes = TextureUtils.ResizeTexture(bytes, width, height,
                    TextureUtils.ImageFilterMode.Biliner, targetWidth, targetHeight, mirrorX, mirrorY);
                    switch (textureFormat)
                    {
                        case TextureFormat.RGB24:

                            break;
                        case TextureFormat.RGBA32:
                            bytes = TextureUtils.RGB2RGBA32(bytes);
                            break;
                        case TextureFormat.ARGB32:
                            bytes = TextureUtils.RGB2ARGB32(bytes);
                            break;
                        case TextureFormat.BGRA32:
                            bytes = TextureUtils.RGB2BGRA32(bytes);
                            break;
                        default:
                            throw new NotImplementedException();

                    }
                    GCHandle handle = GCHandle.Alloc(bytes, GCHandleType.Pinned);
                    if (dataDic.ContainsKey(nativeHandle))
                    {
                        dataDic[nativeHandle] = handle;
                    }
                    else
                    {
                        dataDic.Add(nativeHandle, handle);

                    }
                    synchronizationContext.Post(state =>
                    {
                        callback(XRCpuImage.AsyncConversionStatus.Ready, conversionParams, handle.AddrOfPinnedObject(), bytes.Length, context);
                    }, null);

                }
                catch (Exception e)
                {
                    Debug.LogError(e.Message);
                    Debug.LogError(e.StackTrace);
                    synchronizationContext.Post(state =>
                 {
                     callback(XRCpuImage.AsyncConversionStatus.Failed, conversionParams, IntPtr.Zero, 0, context);
                 }, null);
                }
            });
            if (taskDic.ContainsKey(nativeHandle))
            {
                taskDic[nativeHandle] = task;

            }
            else
            {
                taskDic.Add(nativeHandle, task);

            }

        }



        public override void DisposeImage(int nativeHandle)
        {
            // nativeHandle is our registry id, not a GCHandle -- release the
            // input NV12 bytes from the registry (not GCHandle.Free).
            ReleaseInputImage(nativeHandle);
            if (taskDic.ContainsKey(nativeHandle))
            {
                taskDic[nativeHandle].Dispose();
                taskDic.Remove(nativeHandle);
            }
            if (dataDic.ContainsKey(nativeHandle))
            {
                dataDic[nativeHandle].Free();   // output pinned buffer (a real GCHandle)
                dataDic.Remove(nativeHandle);
            }
        }

        public override XRCpuImage.AsyncConversionStatus GetAsyncRequestStatus(int requestId)
        {
            if (taskDic.ContainsKey(requestId))
            {
                Task task = taskDic[requestId];
                if (task.IsCompletedSuccessfully)
                {
                    return XRCpuImage.AsyncConversionStatus.Ready;
                }
                else if (task.IsFaulted)
                {
                    return XRCpuImage.AsyncConversionStatus.Failed;
                }
                else if (task.IsCanceled)
                {
                    return XRCpuImage.AsyncConversionStatus.Disposed;
                }
                else
                {
                    return XRCpuImage.AsyncConversionStatus.Processing;
                }

            }
            else
            {
                return XRCpuImage.AsyncConversionStatus.Disposed;
            }
        }
        public override bool NativeHandleValid(int nativeHandle)
        {
            try
            {
                if (GetInputImage(nativeHandle) != null)
                {
                    return true;
                }
                else
                {
                    Debug.Log($"CpuImage NativeHandle Not Valid: {nativeHandle}");
                    return false;
                }
            }
            catch (Exception e)
            {
                Debug.LogError(e.Message);
                Debug.LogError(e.StackTrace);
                return false;
            }


        }
        public override bool TryConvert(int nativeHandle, XRCpuImage.ConversionParams conversionParams, IntPtr destinationBuffer, int bufferLength)
        {
            try
            {
                byte[] bytes = GetInputImage(nativeHandle)?.Bytes;
                int width = conversionParams.inputRect.width;
                int height = conversionParams.inputRect.height;
                int targetWidth = conversionParams.outputDimensions.x;
                int targetHeight = conversionParams.outputDimensions.y;
                bool mirrorX = conversionParams.transformation.HasFlag(XRCpuImage.Transformation.MirrorX);
                bool mirrorY = conversionParams.transformation.HasFlag(XRCpuImage.Transformation.MirrorY);
                bytes = TextureUtils.DecodeYUV2RGB(bytes, TextureUtils.YuvType.NV12, width, height);
                bytes = TextureUtils.ResizeTexture(bytes, width, height,
                TextureUtils.ImageFilterMode.Biliner, targetWidth, targetHeight, mirrorX, mirrorY);
                TextureFormat textureFormat = conversionParams.outputFormat;
                switch (textureFormat)
                {
                    case TextureFormat.RGB24:

                        break;
                    case TextureFormat.RGBA32:
                        bytes = TextureUtils.RGB2RGBA32(bytes);
                        break;
                    case TextureFormat.ARGB32:
                        bytes = TextureUtils.RGB2ARGB32(bytes);
                        break;
                    case TextureFormat.BGRA32:
                        bytes = TextureUtils.RGB2BGRA32(bytes);
                        break;
                    default:
                        throw new NotImplementedException();
                }
                Marshal.Copy(bytes, 0, destinationBuffer, bytes.Length);
                return true;

            }
            catch (Exception e)
            {
                Debug.LogError(e.Message);
                Debug.LogError(e.StackTrace);
                return false;
            }

        }
        public override bool TryGetAsyncRequestData(int requestId, out IntPtr dataPtr, out int dataLength)
        {
            if (dataDic.ContainsKey(requestId))
            {
                GCHandle handle = dataDic[requestId];
                dataPtr = handle.AddrOfPinnedObject();
                byte[] bytes = (byte[])dataDic[requestId].Target;
                dataLength = bytes.Length;
                return true;
            }
            else
            {
                dataPtr = IntPtr.Zero;
                dataLength = 0;
                return false;
            }
        }
        public override bool TryGetConvertedDataSize(int nativeHandle, Vector2Int dimensions, TextureFormat format, out int size)
        {
            if (s_SupportedVideoConversionFormats.Contains(format))
            {
                size = dimensions.x * dimensions.y;
                int bytePerPixel = 0;
                switch (format)
                {
                    case TextureFormat.R16:
                        bytePerPixel = 2;
                        break;
                    case TextureFormat.RGB24:
                        bytePerPixel = 3;
                        break;
                    case TextureFormat.RGBA32:
                    case TextureFormat.ARGB32:
                    case TextureFormat.BGRA32:
                    case TextureFormat.RFloat:
                        bytePerPixel = 4;
                        break;
                    default:
                        bytePerPixel = 1;
                        break;
                }

                size *= bytePerPixel;
                return true;
            }
            else
            {
                size = 0;
                return false;
            }


        }

        public override bool TryGetPlane(int nativeHandle, int planeIndex, out XRCpuImage.Plane.Cinfo planeCinfo)
        {
            // Serve plane pointers from the acquired NV12 snapshot (pinned in the
            // registry) instead of re-acquiring the live preview image. The old
            // implementation released the NDK image (hwArImage.Dispose) *before*
            // handing its plane pointer to AR Foundation -- a use-after-free --
            // and could also return planes of a newer frame than the one this
            // handle was acquired for.
            //
            // NV12 layout, exposed with standard YUV_420_888 plane semantics:
            //   plane 0 (Y): offset 0,        rowStride = width, pixelStride = 1
            //   plane 1 (U): offset w*h,      rowStride = width, pixelStride = 2
            //   plane 2 (V): offset w*h + 1,  rowStride = width, pixelStride = 2
            InputImage image = GetInputImage(nativeHandle);
            if (image == null)
            {
                planeCinfo = default;
                return false;
            }
            int ySize = image.width * image.height;
            int uvSize = ySize / 2;
            IntPtr baseAddr = image.pinnedBytes.AddrOfPinnedObject();
            switch (planeIndex)
            {
                case 0:
                    planeCinfo = new XRCpuImage.Plane.Cinfo(baseAddr, ySize, image.width, 1);
                    return true;
                case 1:
                    planeCinfo = new XRCpuImage.Plane.Cinfo(baseAddr + ySize, uvSize - 1, image.width, 2);
                    return true;
                case 2:
                    planeCinfo = new XRCpuImage.Plane.Cinfo(baseAddr + ySize + 1, uvSize - 1, image.width, 2);
                    return true;
                default:
                    planeCinfo = default;
                    return false;
            }
        }
    }
}
