using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARSubsystems;
namespace UnityEngine.XR.AREngine
{
    public class AREngineRaycastSubsystem : XRRaycastSubsystem
    {
        public const string SubsystemId = "AREngine-Raycast";
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void RegisterDescriptor()
        {

            var cinfo = new XRRaycastSubsystemDescriptor.Cinfo
            {
                id = SubsystemId,
                providerType = typeof(AREngineRaycastSubsystem.AREngineProvider),
                subsystemTypeOverride = typeof(AREngineRaycastSubsystem),
                supportsViewportBasedRaycast = true,
                supportsWorldBasedRaycast = true,
                supportedTrackableTypes =
                    (TrackableType.Planes & ~TrackableType.PlaneWithinInfinity) |
                    TrackableType.FeaturePoint |
                    TrackableType.Depth,
                supportsTrackedRaycasts = true,
            };
            // ARF 6.0 renamed RegisterDescriptor -> Register (old name is
            // UnityUpgradable-obsolete on 6.x). See AREngineCameraSubsystem.
#if ARF_6_OR_NEWER
            XRRaycastSubsystemDescriptor.Register(cinfo);
#else
            XRRaycastSubsystemDescriptor.RegisterDescriptor(cinfo);
#endif
        }
        public class AREngineProvider : Provider
        {

            public override void Start()
            {
               ARConfigHandler.Instance.AddFeature(this,Feature.Raycast);
            }
            public override void Stop()
            {
                ARConfigHandler.Instance.RemoveFeature(this);
            }

        }

    }
}

